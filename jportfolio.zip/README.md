# Single-Page Portfolio - Jagan Mohan Lingam

A responsive Single-Page Application (SPA) portfolio built using HTML5, CSS3, JavaScript, and Bootstrap 5.

## Usage
- **XAMPP:** Extract into `htdocs/portfolio` and access `http://localhost/portfolio`.
- **Vercel:** Deploy instantly as a static web project.
